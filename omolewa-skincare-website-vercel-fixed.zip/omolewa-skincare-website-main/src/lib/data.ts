import { getSupabase, isMissingTable } from './supabase'
import { DEFAULT_SETTINGS, DEMO_PRODUCTS, DEMO_REVIEWS } from './fixtures'
import type { Product, Review, SiteSettings } from './types'

function normalizeProduct(row: Product): Product {
  return { ...row, price: Number(row.price) }
}

export async function fetchSettings(): Promise<SiteSettings> {
  try {
    const { data, error } = await getSupabase()
      .from('site_settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
    if (error || !data) return DEFAULT_SETTINGS
    const merged = { ...DEFAULT_SETTINGS }
    for (const key of Object.keys(DEFAULT_SETTINGS) as (keyof SiteSettings)[]) {
      const value = (data as Record<string, unknown>)[key]
      if (typeof value === 'string') merged[key] = value
    }
    return merged
  } catch {
    return DEFAULT_SETTINGS
  }
}

export async function fetchProducts(): Promise<Product[]> {
  try {
    const { data, error } = await getSupabase()
      .from('products')
      .select('*')
      .order('created_at', { ascending: false })
    if (error) {
      if (isMissingTable(error) || !error.code) return DEMO_PRODUCTS
      throw new Error(error.message)
    }
    return (data as Product[]).map(normalizeProduct)
  } catch (err) {
    if (err instanceof TypeError) return DEMO_PRODUCTS // network failure
    throw err
  }
}

export async function fetchProduct(id: string): Promise<Product | null> {
  if (id.startsWith('demo-')) return DEMO_PRODUCTS.find((p) => p.id === id) ?? null
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null
  const { data, error } = await getSupabase()
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle()
  if (error) throw new Error(error.message)
  return data ? normalizeProduct(data as Product) : null
}

export async function fetchReviews(): Promise<Review[]> {
  try {
    const { data, error } = await getSupabase()
      .from('reviews')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200)
    if (error) {
      if (isMissingTable(error) || !error.code) return DEMO_REVIEWS
      throw new Error(error.message)
    }
    return data as Review[]
  } catch (err) {
    if (err instanceof TypeError) return DEMO_REVIEWS
    throw err
  }
}

export async function submitReview(input: {
  name: string
  rating: number
  comment: string
}) {
  const { error } = await getSupabase().from('reviews').insert(input)
  if (error) {
    throw new Error(
      isMissingTable(error)
        ? 'Reviews are not open yet — please check back soon.'
        : error.message,
    )
  }
}
