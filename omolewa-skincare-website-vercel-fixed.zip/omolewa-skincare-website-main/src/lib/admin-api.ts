// Admin-only writes. Row Level Security (supabase/setup.sql) rejects these
// unless the signed-in Supabase user is the admin email.
import { IMAGE_BUCKET } from './config'
import { getSupabase, isMissingTable } from './supabase'
import type { Product, Review, SiteSettings } from './types'

export const SETUP_MESSAGE =
  'Your Supabase database is not set up yet. Open Supabase → SQL Editor, paste the contents of supabase/setup.sql and click Run.'

function fail(error: { code?: string; message: string }): never {
  throw new Error(isMissingTable(error) ? SETUP_MESSAGE : error.message)
}

export type ProductInput = Omit<Product, 'id' | 'created_at'>

export async function adminListProducts(): Promise<{ products: Product[]; setupNeeded: boolean }> {
  const { data, error } = await getSupabase()
    .from('products')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) {
    if (isMissingTable(error)) return { products: [], setupNeeded: true }
    fail(error)
  }
  return {
    products: (data as Product[]).map((p) => ({ ...p, price: Number(p.price) })),
    setupNeeded: false,
  }
}

export async function adminSaveProduct(input: ProductInput, id?: string) {
  const table = getSupabase().from('products')
  const { error } = id ? await table.update(input).eq('id', id) : await table.insert(input)
  if (error) fail(error)
}

export async function adminDeleteProduct(id: string) {
  const { error } = await getSupabase().from('products').delete().eq('id', id)
  if (error) fail(error)
}

export async function adminUploadImage(file: File) {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
  const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`
  const storage = getSupabase().storage.from(IMAGE_BUCKET)
  const { error } = await storage.upload(path, file, {
    cacheControl: '31536000',
    contentType: file.type || undefined,
  })
  if (error) {
    throw new Error(
      /bucket not found/i.test(error.message) ? SETUP_MESSAGE : error.message,
    )
  }
  return storage.getPublicUrl(path).data.publicUrl
}

export async function adminSaveSettings(settings: SiteSettings) {
  const { error } = await getSupabase()
    .from('site_settings')
    .upsert({ id: 1, ...settings, updated_at: new Date().toISOString() })
  if (error) fail(error)
}

export async function adminListReviews(): Promise<Review[]> {
  const { data, error } = await getSupabase()
    .from('reviews')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) {
    if (isMissingTable(error)) return []
    fail(error)
  }
  return data as Review[]
}

export async function adminDeleteReview(id: string) {
  const { error } = await getSupabase().from('reviews').delete().eq('id', id)
  if (error) fail(error)
}
