import { createClient, type SupabaseClient } from '@supabase/supabase-js'
import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from './config'

let client: SupabaseClient | undefined

export function getSupabase(): SupabaseClient {
  if (!client) {
    const isBrowser = typeof window !== 'undefined'
    client = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: { persistSession: isBrowser, autoRefreshToken: isBrowser },
    })
  }
  return client
}

/** True when Supabase says the table doesn't exist yet (setup.sql not run). */
export function isMissingTable(error: { code?: string } | null | undefined) {
  return error?.code === 'PGRST205' || error?.code === '42P01'
}
