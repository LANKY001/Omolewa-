// Public Supabase project details. The publishable key is safe to ship to the
// browser — Row Level Security in supabase/setup.sql protects every write.
// Override with VITE_SUPABASE_URL / VITE_SUPABASE_PUBLISHABLE_KEY on any host.
export const SUPABASE_URL =
  import.meta.env.VITE_SUPABASE_URL || 'https://dyuxjtmynjpjvomrbaei.supabase.co'
export const SUPABASE_PUBLISHABLE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  'sb_publishable_Qpl-GA-AbRUWK72_NPsmsA_wUKjRejG'

// Only this Supabase Auth account may use the admin dashboard (enforced by RLS).
export const ADMIN_EMAIL = 'omolewaevnt2@gmail.com'

export const IMAGE_BUCKET = 'product-images'
