export type Section = 'skincare' | 'event'

export interface Product {
  id: string
  name: string
  section: Section
  category: string
  price: number
  price_unit: string | null
  description: string | null
  details: string | null
  image_url: string | null
  featured: boolean
  in_stock: boolean
  created_at?: string
}

export interface SiteSettings {
  site_name: string
  tagline: string
  announcement: string
  about: string
  address: string
  phone: string
  email: string
  whatsapp: string
  facebook: string
  instagram: string
  telegram: string
  tiktok: string
}

export interface Review {
  id: string
  name: string
  rating: number
  comment: string
  created_at: string
}

export const SECTION_LABELS: Record<Section, string> = {
  skincare: 'Skincare',
  event: 'Event Hire',
}
