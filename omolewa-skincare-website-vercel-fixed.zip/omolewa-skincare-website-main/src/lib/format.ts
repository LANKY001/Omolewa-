const ngn = new Intl.NumberFormat('en-NG', {
  style: 'currency',
  currency: 'NGN',
  maximumFractionDigits: 0,
})

export function formatNGN(amount: number) {
  return ngn.format(amount)
}

/** Normalises a Nigerian number (e.g. 0803…, +234 803…) for wa.me links. */
export function normalizeWhatsapp(input: string) {
  let digits = input.replace(/\D/g, '')
  if (digits.startsWith('0')) digits = '234' + digits.slice(1)
  return digits
}

export function whatsappLink(number: string, message?: string) {
  const digits = normalizeWhatsapp(number)
  const base = digits ? `https://wa.me/${digits}` : 'https://wa.me/'
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

/** Accepts a full URL or a bare handle and returns a usable profile link. */
export function socialUrl(
  network: 'facebook' | 'instagram' | 'telegram' | 'tiktok',
  value: string,
) {
  const v = value.trim()
  if (!v) return ''
  if (/^https?:\/\//i.test(v)) return v
  const handle = v.replace(/^@/, '')
  switch (network) {
    case 'facebook':
      return `https://facebook.com/${handle}`
    case 'instagram':
      return `https://instagram.com/${handle}`
    case 'telegram':
      return `https://t.me/${handle}`
    case 'tiktok':
      return `https://www.tiktok.com/@${handle}`
  }
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-NG', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}
