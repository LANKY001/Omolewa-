// Starter content shown until the Supabase tables are created with
// supabase/setup.sql. Once the database is live, real data replaces these.
import type { Product, Review, SiteSettings } from './types'

export const DEFAULT_SETTINGS: SiteSettings = {
  site_name: 'Omolewa Event and Skincare',
  tagline: 'Radiant skin. Unforgettable celebrations.',
  announcement:
    'Free Lagos delivery on skincare orders above ₦50,000 · Book event rentals early for December!',
  about:
    'Omolewa brings together two passions: skin that glows and celebrations that dazzle. We hand-pick gentle, effective skincare made with African botanicals, and we rent out beautifully kept tents, chairs, tables and décor for weddings, birthdays, owambes and corporate events across Nigeria.',
  address: 'Lagos, Nigeria',
  phone: '+234 800 000 0000',
  email: 'omolewaevnt2@gmail.com',
  whatsapp: '2348000000000',
  facebook: '',
  instagram: '',
  telegram: '',
  tiktok: '',
}

export const DEMO_PRODUCTS: Product[] = [
  {
    id: 'demo-glow-serum',
    name: 'Vitamin C Glow Serum',
    section: 'skincare',
    category: 'Serums',
    price: 18500,
    price_unit: null,
    description:
      'A lightweight brightening serum that fades dark spots and leaves skin luminous.',
    details:
      '30ml amber dropper bottle\n15% stabilised vitamin C\nSuitable for all skin types\nUse morning and night',
    image_url: '/img/p-glow-serum.webp',
    featured: true,
    in_stock: true,
  },
  {
    id: 'demo-shea-butter',
    name: 'Whipped Shea Body Butter',
    section: 'skincare',
    category: 'Body Care',
    price: 12000,
    price_unit: null,
    description:
      'Rich, melt-in raw African shea whipped with coconut oil for deep, lasting moisture.',
    details:
      '250g jar\n100% raw Ghanaian shea\nFragrance: soft vanilla\nGreat for dry skin and stretch marks',
    image_url: '/img/p-shea-butter.webp',
    featured: true,
    in_stock: true,
  },
  {
    id: 'demo-black-soap',
    name: 'African Black Soap Set',
    section: 'skincare',
    category: 'Cleansers',
    price: 9500,
    price_unit: null,
    description:
      'Traditional black soap bars with a gentle foaming wash for clear, balanced skin.',
    details:
      '2 soap bars + 200ml liquid wash\nPlantain skin ash & palm kernel oil\nHelps with acne and oily skin',
    image_url: '/img/p-black-soap.webp',
    featured: true,
    in_stock: true,
  },
  {
    id: 'demo-pagoda-tent',
    name: 'Pagoda Party Tent',
    section: 'event',
    category: 'Tents',
    price: 150000,
    price_unit: 'per day',
    description:
      'Elegant white pagoda tent with draped cream fabric — perfect for weddings and owambes.',
    details:
      'Seats up to 150 guests\nIncludes drapes and fairy lights\nSetup and pickup included in Lagos',
    image_url: '/img/p-tent.webp',
    featured: true,
    in_stock: true,
  },
  {
    id: 'demo-chiavari-chairs',
    name: 'Gold Chiavari Chairs',
    section: 'event',
    category: 'Chairs & Tables',
    price: 2500,
    price_unit: 'per chair',
    description:
      'Classic gold chiavari chairs with cream cushions to elevate any reception.',
    details:
      'Minimum order: 50 chairs\nCushions included\nRound banquet tables available',
    image_url: '/img/p-chairs.webp',
    featured: true,
    in_stock: true,
  },
  {
    id: 'demo-table-decor',
    name: 'Luxury Table Décor Package',
    section: 'event',
    category: 'Décor',
    price: 45000,
    price_unit: 'per table',
    description:
      'Gold candelabra centrepieces with fresh blush roses, runners and charger plates.',
    details:
      'Fresh or silk flowers\nGold charger plates & napkins\nCustom colour themes available',
    image_url: '/img/p-decor.webp',
    featured: true,
    in_stock: true,
  },
]

export const DEMO_REVIEWS: Review[] = [
  {
    id: 'demo-r1',
    name: 'Adaeze O.',
    rating: 5,
    comment:
      'The tent and chairs for my mum’s 60th were stunning. Setup was on time and everyone kept asking who did the décor!',
    created_at: '2026-09-20T10:00:00Z',
  },
  {
    id: 'demo-r2',
    name: 'Tolani B.',
    rating: 5,
    comment:
      'My skin has never been this smooth. The shea butter is pure luxury and the glow serum faded my dark spots in weeks.',
    created_at: '2026-09-02T10:00:00Z',
  },
  {
    id: 'demo-r3',
    name: 'Chinedu A.',
    rating: 4,
    comment:
      'Professional team, beautiful table décor for our corporate dinner. Will book again.',
    created_at: '2026-08-15T10:00:00Z',
  },
]
