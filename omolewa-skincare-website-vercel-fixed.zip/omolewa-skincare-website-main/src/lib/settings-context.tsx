import { createContext, useContext } from 'react'
import { DEFAULT_SETTINGS } from './fixtures'
import type { SiteSettings } from './types'

const SettingsContext = createContext<SiteSettings>(DEFAULT_SETTINGS)

export const SettingsProvider = SettingsContext.Provider

export function useSettings() {
  return useContext(SettingsContext)
}
