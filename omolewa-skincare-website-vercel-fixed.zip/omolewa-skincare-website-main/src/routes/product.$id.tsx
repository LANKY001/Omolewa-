import { useEffect, useState } from 'react'
import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { ArrowLeft, Check, Minus, Plus, ShoppingBag } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/site/product-card'
import { WhatsAppIcon } from '@/components/site/social-icons'
import { useCart } from '@/lib/cart'
import { fetchProduct, fetchProducts } from '@/lib/data'
import { formatNGN, whatsappLink } from '@/lib/format'
import { useSettings } from '@/lib/settings-context'
import { SECTION_LABELS } from '@/lib/types'

export const Route = createFileRoute('/product/$id')({
  loader: async ({ params }) => {
    const product = await fetchProduct(params.id)
    if (!product) throw notFound()
    const all = await fetchProducts()
    const related = all
      .filter((p) => p.section === product.section && p.id !== product.id)
      .slice(0, 3)
    return { product, related }
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: loaderData.product.name },
          { name: 'description', content: loaderData.product.description ?? '' },
          ...(loaderData.product.image_url
            ? [{ property: 'og:image', content: loaderData.product.image_url }]
            : []),
        ]
      : [],
  }),
  component: ProductPage,
})

function ProductPage() {
  const { product, related } = Route.useLoaderData()
  const settings = useSettings()
  const cart = useCart()
  const [qty, setQty] = useState(1)

  const details = (product.details ?? '').split('\n').map((d) => d.trim()).filter(Boolean)
  const isEvent = product.section === 'event'
  const [pageUrl, setPageUrl] = useState('')
  useEffect(() => setPageUrl(window.location.href), [product.id])
  const message = [
    `Hello ${settings.site_name}, I'd like to ${isEvent ? 'book' : 'order'}:`,
    `${product.name} × ${qty}`,
    `Price: ${formatNGN(product.price)}${product.price_unit ? ` ${product.price_unit}` : ''}`,
    `Total: ${formatNGN(product.price * qty)}`,
    pageUrl,
  ]
    .filter(Boolean)
    .join('\n')

  return (
    <div className="mx-auto max-w-content px-4 pt-10 sm:px-6">
      <Link
        to="/shop"
        search={{ section: product.section }}
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
      >
        <ArrowLeft className="size-4" /> Back to {SECTION_LABELS[product.section]}
      </Link>

      <article className="swag-edge glass mt-6 grid gap-10 rounded-[2.25rem] p-5 pt-12 sm:p-8 sm:pt-14 lg:grid-cols-2">
        <div className="floral-box floral-box-lg">
          <div className="aspect-square overflow-hidden rounded-[1.75rem] bg-muted shadow-xl">
            {product.image_url ? (
              <img src={product.image_url} alt={product.name} className="size-full object-cover" />
            ) : (
              <div className="flex size-full items-center justify-center font-display text-4xl text-muted-foreground">
                Omolewa
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col">
          <p className="text-xs tracking-[0.3em] text-primary uppercase">
            {SECTION_LABELS[product.section]} · {product.category}
          </p>
          <h1 className="mt-3 text-5xl leading-tight font-semibold">{product.name}</h1>
          <p className="mt-4 text-3xl font-medium text-primary">
            {formatNGN(product.price)}
            {product.price_unit && (
              <span className="ml-2 text-base font-normal text-muted-foreground">{product.price_unit}</span>
            )}
          </p>
          <div className="gold-rule my-6 w-full" aria-hidden="true" />
          {product.description && (
            <p className="leading-relaxed text-muted-foreground">{product.description}</p>
          )}
          {details.length > 0 && (
            <ul className="mt-6 space-y-2">
              {details.map((d) => (
                <li key={d} className="flex gap-3">
                  <Check className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden="true" />
                  <span>{d}</span>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <div className="glass inline-flex items-center rounded-full p-1" role="group" aria-label="Quantity">
              <button
                type="button"
                aria-label="Decrease quantity"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="inline-flex size-9 items-center justify-center rounded-full hover:bg-white/70"
              >
                <Minus className="size-4" />
              </button>
              <span className="w-10 text-center tabular-nums" aria-live="polite">{qty}</span>
              <button
                type="button"
                aria-label="Increase quantity"
                onClick={() => setQty((q) => q + 1)}
                className="inline-flex size-9 items-center justify-center rounded-full hover:bg-white/70"
              >
                <Plus className="size-4" />
              </button>
            </div>
            <p className="text-sm text-muted-foreground">
              Total <span className="font-semibold text-foreground">{formatNGN(product.price * qty)}</span>
            </p>
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="h-12 flex-1 rounded-full text-base shadow-lg">
              <a href={whatsappLink(settings.whatsapp, message)} target="_blank" rel="noopener noreferrer">
                <WhatsAppIcon className="size-5" /> {isEvent ? 'Book now on WhatsApp' : 'Order now on WhatsApp'}
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-12 flex-1 rounded-full border-primary/30 bg-cream/70 text-base text-primary hover:bg-cream"
              disabled={!product.in_stock}
              onClick={() => {
                cart.add(product, qty)
                toast.success(`${product.name} added to your bag`, {
                  action: { label: 'View bag', onClick: () => cart.setOpen(true) },
                })
              }}
            >
              <ShoppingBag /> Add to bag
            </Button>
          </div>
          {!product.in_stock && (
            <p className="mt-3 text-sm text-destructive">
              {isEvent ? 'Currently fully booked — message us for other dates.' : 'Currently sold out.'}
            </p>
          )}
        </div>
      </article>

      {related.length > 0 && (
        <section className="mt-20">
          <h2 className="text-center text-4xl font-semibold">You may also like</h2>
          <div className="mt-10 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
