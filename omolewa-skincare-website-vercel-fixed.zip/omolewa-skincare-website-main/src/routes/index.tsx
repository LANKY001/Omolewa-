import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, Flower2, PartyPopper, Sparkles, Truck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/site/product-card'
import { SectionHeading } from '@/components/site/section-heading'
import { Stars } from '@/components/site/stars'
import { WhatsAppIcon } from '@/components/site/social-icons'
import { fetchProducts, fetchReviews } from '@/lib/data'
import { formatDate, whatsappLink } from '@/lib/format'
import { useSettings } from '@/lib/settings-context'
import type { Product, Section } from '@/lib/types'

export const Route = createFileRoute('/')({
  loader: async () => {
    const [products, reviews] = await Promise.all([fetchProducts(), fetchReviews()])
    return { products, reviews: reviews.slice(0, 3) }
  },
  component: Home,
})

function pick(products: Product[], section: Section) {
  const inSection = products.filter((p) => p.section === section)
  const featured = inSection.filter((p) => p.featured)
  return (featured.length >= 3 ? featured : inSection).slice(0, 3)
}

function Home() {
  const { products, reviews } = Route.useLoaderData()
  const settings = useSettings()

  return (
    <>
      {/* Hero — Nigerian party tent backdrop */}
      <section className="relative isolate -mt-px overflow-hidden">
        <img
          src="/img/hero-tent.webp"
          alt="An elegant cream party tent with gold chairs and floral tables at a Nigerian garden celebration"
          className="absolute inset-0 -z-20 size-full object-cover"
          fetchPriority="high"
        />
        <div
          className="absolute inset-0 -z-10 bg-gradient-to-r from-[oklch(0.3_0.06_15/0.72)] via-[oklch(0.35_0.06_15/0.35)] to-transparent"
          aria-hidden="true"
        />
        <div className="mx-auto flex min-h-[78svh] max-w-content items-center px-4 py-20 sm:px-6">
          <div className="floral-box floral-box-lg glass max-w-xl rounded-[2rem] p-8 sm:p-10">
            <p className="text-xs font-medium tracking-[0.35em] text-primary uppercase">
              Lagos · Skincare &amp; Event Hire
            </p>
            <h1 className="mt-4 text-5xl leading-[1.02] font-semibold sm:text-6xl">
              {settings.site_name}
            </h1>
            <p className="mt-4 font-display text-2xl text-primary italic">
              {settings.tagline}
            </p>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Glow with botanical skincare, then celebrate in style with tents,
              chairs, tables and luxury décor for every owambe, wedding and milestone.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="rounded-full px-7 shadow-lg">
                <Link to="/shop" search={{ section: 'skincare' }}>
                  Shop skincare <ArrowRight />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full border-primary/30 bg-cream/70 px-7 text-primary hover:bg-cream"
              >
                <Link to="/shop" search={{ section: 'event' }}>
                  Hire for your event
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="mx-auto -mt-10 max-w-content px-4 sm:px-6">
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { Icon: Flower2, title: 'Botanical formulas', text: 'Shea, black soap & vitamin C' },
            { Icon: PartyPopper, title: 'Owambe-ready', text: 'Tents, chairs, tables, décor' },
            { Icon: Truck, title: 'Lagos delivery', text: 'Setup & pickup handled' },
            { Icon: Sparkles, title: 'Order on WhatsApp', text: 'Fast, friendly replies' },
          ].map(({ Icon, title, text }) => (
            <li key={title} className="glass lift flex items-center gap-4 rounded-2xl p-5">
              <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-medium">{title}</p>
                <p className="text-sm text-muted-foreground">{text}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <Showcase
        id="skincare"
        eyebrow="The glow edit"
        title="Skincare collection"
        description="Gentle, effective care for melanin-rich skin — made with ingredients you can trust."
        products={pick(products, 'skincare')}
        section="skincare"
      />

      <Showcase
        id="events"
        eyebrow="Celebrate beautifully"
        title="Event hire"
        description="From intimate dinners to grand owambes — elegant rentals delivered, set up and collected."
        products={pick(products, 'event')}
        section="event"
      />

      {/* About teaser */}
      <section className="mx-auto mt-24 max-w-content px-4 sm:px-6">
        <div className="swag-edge glass grid items-center gap-10 overflow-hidden rounded-[2rem] p-6 pt-12 md:grid-cols-2 md:p-10 md:pt-14">
          <div className="floral-box">
            <img
              src="/img/about.webp"
              alt="The Omolewa founder arranging blush roses on an event table"
              loading="lazy"
              className="aspect-[4/3] w-full rounded-[1.5rem] object-cover shadow-xl"
            />
          </div>
          <div>
            <SectionHeading align="left" eyebrow="Our story" title="Beauty for you, magic for your guests" />
            <p className="mt-5 leading-relaxed text-muted-foreground">{settings.about}</p>
            <Button asChild variant="link" className="mt-4 px-0 text-base">
              <Link to="/about">
                Read more about us <ArrowRight />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Reviews teaser */}
      <section className="mx-auto mt-24 max-w-content px-4 sm:px-6">
        <SectionHeading
          eyebrow="Kind words"
          title="Loved by our clients"
          description="Real experiences from brides, celebrants and skincare lovers."
        />
        {reviews.length === 0 ? (
          <p className="mt-10 text-center text-muted-foreground">
            No reviews yet — be the first to share your experience.
          </p>
        ) : (
          <ul className="mt-12 grid gap-8 md:grid-cols-3">
            {reviews.map((r) => (
              <li key={r.id} className="floral-box glass lift flex flex-col gap-4 rounded-[1.75rem] p-7">
                <Stars rating={r.rating} />
                <blockquote className="font-display text-xl leading-snug italic">
                  “{r.comment}”
                </blockquote>
                <p className="mt-auto text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">{r.name}</span> · {formatDate(r.created_at)}
                </p>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-10 flex justify-center">
          <Button asChild variant="outline" className="rounded-full border-primary/30 bg-cream/60 text-primary">
            <Link to="/reviews">Read all reviews &amp; leave yours</Link>
          </Button>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto mt-24 max-w-content px-4 sm:px-6">
        <div className="floral-box floral-box-lg rounded-[2rem] bg-primary px-6 py-14 text-center text-primary-foreground shadow-2xl sm:px-12">
          <h2 className="text-4xl font-semibold sm:text-5xl">Planning something special?</h2>
          <p className="mx-auto mt-4 max-w-reading text-primary-foreground/85">
            Tell us your date, guest count and colour theme — we’ll put together a
            package that fits your budget.
          </p>
          <Button asChild size="lg" variant="secondary" className="mt-8 rounded-full px-8">
            <a
              href={whatsappLink(settings.whatsapp, `Hello ${settings.site_name}, I'd like a quote for my event.`)}
              target="_blank"
              rel="noopener noreferrer"
            >
              <WhatsAppIcon className="size-5" /> Chat with us on WhatsApp
            </a>
          </Button>
        </div>
      </section>
    </>
  )
}

function Showcase({
  id,
  eyebrow,
  title,
  description,
  products,
  section,
}: {
  id: string
  eyebrow: string
  title: string
  description: string
  products: Product[]
  section: Section
}) {
  return (
    <section id={id} className="mx-auto mt-24 max-w-content px-4 sm:px-6">
      <div className="swag-edge glass rounded-[2.25rem] px-5 pt-16 pb-10 sm:px-10">
        <SectionHeading eyebrow={eyebrow} title={title} description={description} />
        {products.length === 0 ? (
          <p className="mt-10 text-center text-muted-foreground">New items are on the way.</p>
        ) : (
          <div className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
        <div className="mt-10 flex justify-center">
          <Button asChild className="rounded-full px-6">
            <Link to="/shop" search={{ section }}>
              View all {title.toLowerCase()} <ArrowRight />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
