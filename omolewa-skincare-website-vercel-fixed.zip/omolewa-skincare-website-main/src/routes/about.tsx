import { Link, createFileRoute } from '@tanstack/react-router'
import { Flower2, Heart, Mail, MapPin, PartyPopper, Phone, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading } from '@/components/site/section-heading'
import { SocialLinks, WhatsAppIcon } from '@/components/site/social-icons'
import { whatsappLink } from '@/lib/format'
import { useSettings } from '@/lib/settings-context'

export const Route = createFileRoute('/about')({
  head: () => ({ meta: [{ title: 'About us' }] }),
  component: About,
})

const SERVICES = [
  {
    Icon: Flower2,
    title: 'Skincare',
    text: 'Serums, body butters and cleansers crafted with shea, black soap and vitamin C for healthy, glowing melanin.',
  },
  {
    Icon: PartyPopper,
    title: 'Tents & canopies',
    text: 'Pagoda, marquee and canopy tents dressed with cream drapes and fairy lights for every size of guest list.',
  },
  {
    Icon: Sparkles,
    title: 'Chairs, tables & décor',
    text: 'Chiavari chairs, banquet tables, centrepieces, runners and charger plates styled to your colour theme.',
  },
  {
    Icon: Heart,
    title: 'Personal service',
    text: 'One friendly contact from enquiry to pickup — we deliver, set up and collect across Lagos and beyond.',
  },
]

function About() {
  const s = useSettings()

  return (
    <div className="mx-auto max-w-content px-4 pt-14 sm:px-6">
      <SectionHeading eyebrow="About us" title={`Welcome to ${s.site_name}`} description={s.tagline} />

      <section className="swag-edge glass mt-12 grid items-center gap-10 rounded-[2.25rem] p-6 pt-14 md:grid-cols-[1fr_1.1fr] md:p-10 md:pt-16">
        <div className="floral-box floral-box-lg">
          <img
            src="/img/about.webp"
            alt="Our founder styling an event table with roses beside our skincare range"
            className="aspect-[4/5] w-full rounded-[1.75rem] object-cover shadow-xl"
          />
        </div>
        <div>
          <h2 className="text-4xl font-semibold">Our story</h2>
          <p className="mt-5 text-lg leading-relaxed whitespace-pre-line text-muted-foreground">{s.about}</p>
          <p className="mt-5 leading-relaxed text-muted-foreground">
            Every product we sell and every item we rent is chosen with the same care:
            quality you can see, service you can feel, and prices that respect your budget.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild className="rounded-full px-6">
              <Link to="/shop">Browse our items</Link>
            </Button>
            <Button asChild variant="outline" className="rounded-full border-primary/30 bg-cream/70 px-6 text-primary">
              <a href={whatsappLink(s.whatsapp, `Hello ${s.site_name}!`)} target="_blank" rel="noopener noreferrer">
                <WhatsAppIcon className="size-4" /> Say hello
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section className="mt-24">
        <SectionHeading eyebrow="What we do" title="Two passions, one promise" />
        <ul className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map(({ Icon, title, text }) => (
            <li key={title} className="floral-box glass lift rounded-[1.75rem] p-7">
              <span className="inline-flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-2xl font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="swag-edge glass mt-24 rounded-[2.25rem] px-6 pt-16 pb-10 text-center sm:px-10">
        <h2 className="text-4xl font-semibold">Find us</h2>
        <ul className="mx-auto mt-8 grid max-w-3xl gap-6 text-sm sm:grid-cols-3">
          <li className="flex flex-col items-center gap-2">
            <MapPin className="size-5 text-primary" aria-hidden="true" />
            <span className="whitespace-pre-line text-muted-foreground">{s.address || '—'}</span>
          </li>
          <li className="flex flex-col items-center gap-2">
            <Phone className="size-5 text-primary" aria-hidden="true" />
            {s.phone ? (
              <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="text-muted-foreground hover:text-primary">{s.phone}</a>
            ) : (
              <span className="text-muted-foreground">—</span>
            )}
          </li>
          <li className="flex flex-col items-center gap-2">
            <Mail className="size-5 text-primary" aria-hidden="true" />
            {s.email ? (
              <a href={`mailto:${s.email}`} className="break-all text-muted-foreground hover:text-primary">{s.email}</a>
            ) : (
              <span className="text-muted-foreground">—</span>
            )}
          </li>
        </ul>
        <SocialLinks className="mt-8 justify-center" />
      </section>
    </div>
  )
}
