import { useState } from 'react'
import { createFileRoute, useRouter } from '@tanstack/react-router'
import { Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { SectionHeading } from '@/components/site/section-heading'
import { StarPicker, Stars } from '@/components/site/stars'
import { fetchReviews, submitReview } from '@/lib/data'
import { formatDate } from '@/lib/format'

export const Route = createFileRoute('/reviews')({
  loader: () => fetchReviews(),
  head: () => ({ meta: [{ title: 'Reviews' }] }),
  component: Reviews,
})

function Reviews() {
  const reviews = Route.useLoaderData()
  const router = useRouter()
  const [name, setName] = useState('')
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const average = reviews.length
    ? reviews.reduce((n, r) => n + r.rating, 0) / reviews.length
    : 0

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim() || !comment.trim()) {
      setError('Please add your name and a few words about your experience.')
      return
    }
    setError(null)
    setPending(true)
    try {
      await submitReview({ name: name.trim().slice(0, 80), rating, comment: comment.trim().slice(0, 1500) })
      toast.success('Thank you! Your review has been posted.')
      setName('')
      setComment('')
      setRating(5)
      await router.invalidate()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
    } finally {
      setPending(false)
    }
  }

  return (
    <div className="mx-auto max-w-content px-4 pt-14 sm:px-6">
      <SectionHeading
        eyebrow="Reviews"
        title="What our clients say"
        description="Shopped our skincare or hired for your event? We’d love to hear from you."
      />

      <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
        <aside className="flex flex-col gap-8">
          <div className="floral-box glass rounded-[1.75rem] p-7 text-center">
            <p className="font-display text-6xl font-semibold text-primary">
              {reviews.length ? average.toFixed(1) : '—'}
            </p>
            <Stars rating={average} className="mt-2 justify-center [&_svg]:size-5" />
            <p className="mt-2 text-sm text-muted-foreground">
              Based on {reviews.length} review{reviews.length === 1 ? '' : 's'}
            </p>
          </div>

          <form onSubmit={onSubmit} className="swag-edge glass flex flex-col gap-5 rounded-[1.75rem] p-7 pt-12" noValidate>
            <h2 className="text-3xl font-semibold">Leave a review</h2>
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium" id="rating-label">Your rating</span>
              <StarPicker value={rating} onChange={setRating} />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="review-name">Your name</Label>
              <Input
                id="review-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={80}
                placeholder="e.g. Funke A."
                className="bg-cream/80"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="review-comment">Your review</Label>
              <Textarea
                id="review-comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                maxLength={1500}
                rows={5}
                placeholder="Tell us about the product or your event…"
                className="bg-cream/80"
              />
            </div>
            {error && (
              <p role="alert" className="text-sm text-destructive">{error}</p>
            )}
            <Button type="submit" size="lg" className="rounded-full" disabled={pending}>
              {pending && <Loader2 className="animate-spin" />} Post review
            </Button>
          </form>
        </aside>

        <section aria-label="All reviews">
          {reviews.length === 0 ? (
            <div className="glass rounded-[1.75rem] p-12 text-center">
              <p className="font-display text-3xl">No reviews yet</p>
              <p className="mt-2 text-muted-foreground">Be the first to share your experience.</p>
            </div>
          ) : (
            <ul className="flex flex-col gap-8">
              {reviews.map((r) => (
                <li key={r.id} className="floral-box glass rounded-[1.75rem] p-7">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium">{r.name}</p>
                    <Stars rating={r.rating} />
                  </div>
                  <p className="mt-3 leading-relaxed text-muted-foreground whitespace-pre-line">{r.comment}</p>
                  <p className="mt-4 text-xs tracking-wider text-muted-foreground/80 uppercase">{formatDate(r.created_at)}</p>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}
