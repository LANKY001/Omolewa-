import {
  HeadContent,
  Outlet,
  Scripts,
  createRootRoute,
} from '@tanstack/react-router'

import { Toaster } from '@/components/ui/sonner'
import { TooltipProvider } from '@/components/ui/tooltip'
import { NotFoundPage } from '@/components/error-pages'
import { AnnouncementBar } from '@/components/site/announcement-bar'
import { SiteHeader } from '@/components/site/site-header'
import { SiteFooter } from '@/components/site/site-footer'
import { CartSheet } from '@/components/site/cart-sheet'
import { CartProvider } from '@/lib/cart'
import { fetchSettings } from '@/lib/data'
import { DEFAULT_SETTINGS } from '@/lib/fixtures'
import { SettingsProvider } from '@/lib/settings-context'

import '../styles.css'

const siteDescription =
  'Luxury skincare made with African botanicals and elegant event rentals — tents, chairs, tables and décor — across Nigeria.'

export const Route = createRootRoute({
  loader: () => fetchSettings(),
  staleTime: 60_000,
  head: ({ loaderData }) => {
    const siteName = loaderData?.site_name ?? DEFAULT_SETTINGS.site_name
    return {
      meta: [
        { charSet: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { title: siteName },
        { name: 'description', content: siteDescription },
        { name: 'theme-color', content: '#f4d6d4' },
        { property: 'og:title', content: siteName },
        { property: 'og:description', content: siteDescription },
        { property: 'og:type', content: 'website' },
        { property: 'og:image', content: '/img/hero-tent.webp' },
        { name: 'twitter:card', content: 'summary_large_image' },
      ],
      links: [
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
        {
          rel: 'stylesheet',
          href: 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500;1,600&family=Jost:wght@300;400;500;600&display=swap',
        },
      ],
    }
  },
  shellComponent: RootDocument,
  component: RootLayout,
  notFoundComponent: NotFoundPage,
})

function RootLayout() {
  const settings = Route.useLoaderData()
  return (
    <SettingsProvider value={settings}>
      <CartProvider>
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
        >
          Skip to content
        </a>
        <AnnouncementBar />
        <SiteHeader />
        <main id="main">
          <Outlet />
        </main>
        <SiteFooter />
        <CartSheet />
      </CartProvider>
    </SettingsProvider>
  )
}

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <TooltipProvider>{children}</TooltipProvider>
        <Toaster position="top-center" richColors />
        <Scripts />
      </body>
    </html>
  )
}
