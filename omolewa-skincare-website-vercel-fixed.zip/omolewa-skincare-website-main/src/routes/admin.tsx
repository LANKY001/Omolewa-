import { useCallback, useEffect, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import type { Session } from '@supabase/supabase-js'
import { AlertTriangle, Loader2, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LoginForm } from '@/components/admin/login-form'
import { ProductsManager } from '@/components/admin/products-manager'
import { ReviewsManager } from '@/components/admin/reviews-manager'
import { SettingsForm } from '@/components/admin/settings-form'
import { SETUP_MESSAGE } from '@/lib/admin-api'
import { ADMIN_EMAIL } from '@/lib/config'
import { getSupabase } from '@/lib/supabase'

export const Route = createFileRoute('/admin')({
  head: () => ({
    meta: [{ title: 'Admin dashboard' }, { name: 'robots', content: 'noindex' }],
  }),
  component: AdminPage,
})

function AdminPage() {
  const [session, setSession] = useState<Session | null | undefined>(undefined)
  const [notice, setNotice] = useState<string | null>(null)
  const [setupNeeded, setSetupNeeded] = useState(false)
  const onSetupNeeded = useCallback((v: boolean) => setSetupNeeded(v), [])

  useEffect(() => {
    const supabase = getSupabase()
    const apply = (s: Session | null) => {
      if (s && s.user.email?.toLowerCase() !== ADMIN_EMAIL) {
        setNotice('This account does not have admin access.')
        void supabase.auth.signOut()
        setSession(null)
        return
      }
      setSession(s)
    }
    void supabase.auth.getSession().then(({ data }) => apply(data.session))
    const { data } = supabase.auth.onAuthStateChange((_event, s) => apply(s))
    return () => data.subscription.unsubscribe()
  }, [])

  if (session === undefined) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center" aria-live="polite">
        <Loader2 className="size-6 animate-spin text-primary" aria-label="Loading" />
      </div>
    )
  }

  if (!session) return <LoginForm notice={notice} />

  return (
    <div className="mx-auto max-w-content px-4 pt-12 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs tracking-[0.3em] text-primary uppercase">Admin dashboard</p>
          <h1 className="mt-2 text-5xl font-semibold">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">Signed in as {session.user.email}</p>
        </div>
        <Button
          variant="outline"
          className="rounded-full border-primary/30 bg-cream/70 text-primary"
          onClick={() => {
            setNotice(null)
            void getSupabase().auth.signOut()
          }}
        >
          <LogOut /> Sign out
        </Button>
      </div>

      {setupNeeded && (
        <div role="alert" className="mt-6 flex gap-3 rounded-2xl border border-gold/50 bg-cream/90 p-4 text-sm">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden="true" />
          <p>{SETUP_MESSAGE} Until then, visitors see the starter items.</p>
        </div>
      )}

      <Tabs defaultValue="items" className="mt-8">
        <TabsList className="glass h-auto flex-wrap rounded-full p-1 group-data-[orientation=horizontal]/tabs:h-auto">
          <TabsTrigger value="items" className="rounded-full px-5 py-2">Items</TabsTrigger>
          <TabsTrigger value="settings" className="rounded-full px-5 py-2">Website &amp; social</TabsTrigger>
          <TabsTrigger value="reviews" className="rounded-full px-5 py-2">Reviews</TabsTrigger>
        </TabsList>
        <TabsContent value="items" className="mt-6">
          <ProductsManager onSetupNeeded={onSetupNeeded} />
        </TabsContent>
        <TabsContent value="settings" className="mt-6">
          <SettingsForm />
        </TabsContent>
        <TabsContent value="reviews" className="mt-6">
          <ReviewsManager />
        </TabsContent>
      </Tabs>
    </div>
  )
}
