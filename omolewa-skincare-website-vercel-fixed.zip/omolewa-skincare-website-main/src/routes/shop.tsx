import { useMemo } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { Search, X } from 'lucide-react'
import { ProductCard } from '@/components/site/product-card'
import { SectionHeading } from '@/components/site/section-heading'
import { fetchProducts } from '@/lib/data'
import { cn } from '@/lib/utils'
import { SECTION_LABELS, type Section } from '@/lib/types'

type Sort = 'newest' | 'price-asc' | 'price-desc'

interface ShopSearch {
  q?: string
  section?: Section
  category?: string
  sort?: Sort
}

export const Route = createFileRoute('/shop')({
  validateSearch: (search: Record<string, unknown>): ShopSearch => ({
    q: typeof search.q === 'string' && search.q ? search.q : undefined,
    section:
      search.section === 'skincare' || search.section === 'event'
        ? search.section
        : undefined,
    category:
      typeof search.category === 'string' && search.category
        ? search.category
        : undefined,
    sort:
      search.sort === 'price-asc' || search.sort === 'price-desc'
        ? search.sort
        : undefined,
  }),
  loader: () => fetchProducts(),
  head: () => ({ meta: [{ title: 'Shop skincare & event hire' }] }),
  component: Shop,
})

function Shop() {
  const products = Route.useLoaderData()
  const { q, section, category, sort } = Route.useSearch()
  const navigate = useNavigate({ from: '/shop' })

  const update = (next: Partial<ShopSearch>) =>
    void navigate({ search: (prev) => ({ ...prev, ...next }), replace: true })

  const categories = useMemo(
    () =>
      [...new Set(products.filter((p) => !section || p.section === section).map((p) => p.category))].sort(),
    [products, section],
  )

  const results = useMemo(() => {
    const term = q?.toLowerCase().trim() ?? ''
    const list = products.filter(
      (p) =>
        (!section || p.section === section) &&
        (!category || p.category === category) &&
        (!term ||
          [p.name, p.category, p.description ?? '', p.details ?? '', SECTION_LABELS[p.section]]
            .join(' ')
            .toLowerCase()
            .includes(term)),
    )
    if (sort === 'price-asc') return [...list].sort((a, b) => a.price - b.price)
    if (sort === 'price-desc') return [...list].sort((a, b) => b.price - a.price)
    return list
  }, [products, q, section, category, sort])

  const title = section ? SECTION_LABELS[section] : 'All items'

  const chip = (active: boolean) =>
    cn(
      'rounded-full px-4 py-2 text-sm font-medium transition-all',
      active
        ? 'bg-primary text-primary-foreground shadow-md'
        : 'glass text-foreground/80 hover:text-primary',
    )

  return (
    <div className="mx-auto max-w-content px-4 pt-14 sm:px-6">
      <SectionHeading
        eyebrow="Shop & hire"
        title={title}
        description={
          section === 'event'
            ? 'Tents, chairs, tables and décor for weddings, birthdays and owambes.'
            : section === 'skincare'
              ? 'Botanical skincare for radiant, healthy skin.'
              : 'Everything from glowing skincare to elegant event rentals.'
        }
      />

      <div className="swag-edge glass mt-10 flex flex-col gap-5 rounded-[2rem] px-5 pt-12 pb-6 sm:px-8">
        <div className="relative">
          <label htmlFor="shop-search" className="sr-only">Search items</label>
          <Search className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <input
            id="shop-search"
            type="search"
            value={q ?? ''}
            onChange={(e) => update({ q: e.target.value || undefined })}
            placeholder="Search by name, category or detail…"
            className="h-12 w-full rounded-full border border-white/80 bg-cream/80 pr-12 pl-11 outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/40"
          />
          {q && (
            <button
              type="button"
              onClick={() => update({ q: undefined })}
              aria-label="Clear search"
              className="absolute top-1/2 right-3 inline-flex size-7 -translate-y-1/2 items-center justify-center rounded-full hover:bg-muted"
            >
              <X className="size-4" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by section">
          <button type="button" className={chip(!section)} aria-pressed={!section} onClick={() => update({ section: undefined, category: undefined })}>
            All
          </button>
          {(Object.keys(SECTION_LABELS) as Section[]).map((s) => (
            <button key={s} type="button" className={chip(section === s)} aria-pressed={section === s} onClick={() => update({ section: s, category: undefined })}>
              {SECTION_LABELS[s]}
            </button>
          ))}
          <label className="ml-auto flex items-center gap-2 text-sm text-muted-foreground">
            Sort
            <select
              value={sort ?? 'newest'}
              onChange={(e) => update({ sort: e.target.value === 'newest' ? undefined : (e.target.value as Sort) })}
              className="h-9 rounded-full border border-white/80 bg-cream/80 px-3 text-foreground outline-none focus-visible:ring-[3px] focus-visible:ring-ring/40"
            >
              <option value="newest">Newest</option>
              <option value="price-asc">Price: low to high</option>
              <option value="price-desc">Price: high to low</option>
            </select>
          </label>
        </div>

        {categories.length > 1 && (
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={category === c}
                onClick={() => update({ category: category === c ? undefined : c })}
                className={cn(
                  'rounded-full border px-3 py-1 text-xs tracking-wide transition-colors',
                  category === c
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border bg-cream/50 text-muted-foreground hover:text-primary',
                )}
              >
                {c}
              </button>
            ))}
          </div>
        )}
      </div>

      <p className="mt-8 text-sm text-muted-foreground" aria-live="polite">
        {results.length} item{results.length === 1 ? '' : 's'}
        {q ? ` matching “${q}”` : ''}
      </p>

      {results.length === 0 ? (
        <div className="glass mt-6 rounded-[2rem] p-12 text-center">
          <p className="font-display text-3xl">Nothing found</p>
          <p className="mt-2 text-muted-foreground">Try another search or clear your filters.</p>
          <button
            type="button"
            onClick={() => void navigate({ search: {}, replace: true })}
            className="mt-6 rounded-full bg-primary px-6 py-2 text-sm text-primary-foreground hover:bg-primary/90"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="mt-6 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  )
}
