import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Stars({
  rating,
  className,
}: {
  rating: number
  className?: string
}) {
  return (
    <span
      className={cn('inline-flex items-center gap-0.5', className)}
      role="img"
      aria-label={`${rating.toFixed(1).replace(/\.0$/, '')} out of 5 stars`}
    >
      {[1, 2, 3, 4, 5].map((n) => (
        <Star
          key={n}
          className={cn(
            'size-4',
            n <= Math.round(rating)
              ? 'fill-gold text-gold'
              : 'fill-transparent text-gold/40',
          )}
        />
      ))}
    </span>
  )
}

export function StarPicker({
  value,
  onChange,
}: {
  value: number
  onChange: (value: number) => void
}) {
  return (
    <div role="radiogroup" aria-label="Your rating" className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          role="radio"
          aria-checked={value === n}
          aria-label={`${n} star${n > 1 ? 's' : ''}`}
          onClick={() => onChange(n)}
          className="rounded-full p-1 transition-transform hover:scale-110 focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none motion-reduce:transition-none"
        >
          <Star
            className={cn(
              'size-8',
              n <= value ? 'fill-gold text-gold' : 'fill-transparent text-gold/50',
            )}
          />
        </button>
      ))}
    </div>
  )
}
