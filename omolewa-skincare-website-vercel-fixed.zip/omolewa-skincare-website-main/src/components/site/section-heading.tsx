import { cn } from '@/lib/utils'

export function SectionHeading({
  eyebrow,
  title,
  description,
  className,
  align = 'center',
}: {
  eyebrow?: string
  title: string
  description?: string
  className?: string
  align?: 'center' | 'left'
}) {
  return (
    <div
      className={cn(
        'flex flex-col gap-3',
        align === 'center' ? 'items-center text-center' : 'items-start',
        className,
      )}
    >
      {eyebrow && (
        <span className="text-xs font-medium tracking-[0.3em] text-primary uppercase">
          {eyebrow}
        </span>
      )}
      <h2 className="text-4xl font-semibold text-foreground sm:text-5xl">{title}</h2>
      <div className="gold-rule w-28" aria-hidden="true" />
      {description && (
        <p className="max-w-reading text-base leading-relaxed text-muted-foreground">
          {description}
        </p>
      )}
    </div>
  )
}
