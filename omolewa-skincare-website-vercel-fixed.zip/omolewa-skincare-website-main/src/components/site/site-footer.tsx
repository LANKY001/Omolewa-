import { Link } from '@tanstack/react-router'
import { Lock, Mail, MapPin, Phone } from 'lucide-react'
import { useSettings } from '@/lib/settings-context'
import { Brand } from './brand'
import { SocialLinks } from './social-icons'

export function SiteFooter() {
  const s = useSettings()
  const year = new Date().getFullYear()

  return (
    <footer className="swag-edge glass mt-24 rounded-t-[2.5rem] border-b-0 pt-14">
      <div className="mx-auto grid max-w-content gap-10 px-4 pb-10 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="flex flex-col gap-4">
          <Brand />
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
            {s.tagline}
          </p>
          <SocialLinks />
        </div>

        <nav aria-label="Footer">
          <h2 className="mb-3 text-xl font-semibold">Explore</h2>
          <ul className="space-y-2 text-sm">
            <li><Link to="/shop" search={{ section: 'skincare' }} className="hover:text-primary">Skincare</Link></li>
            <li><Link to="/shop" search={{ section: 'event' }} className="hover:text-primary">Event Hire</Link></li>
            <li><Link to="/shop" className="hover:text-primary">All items</Link></li>
            <li><Link to="/about" className="hover:text-primary">About us</Link></li>
            <li><Link to="/reviews" className="hover:text-primary">Reviews</Link></li>
          </ul>
        </nav>

        <div>
          <h2 className="mb-3 text-xl font-semibold">Visit &amp; contact</h2>
          <ul className="space-y-3 text-sm text-muted-foreground">
            {s.address && (
              <li className="flex gap-2">
                <MapPin className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                <span className="whitespace-pre-line">{s.address}</span>
              </li>
            )}
            {s.phone && (
              <li className="flex gap-2">
                <Phone className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="hover:text-primary">{s.phone}</a>
              </li>
            )}
            {s.email && (
              <li className="flex gap-2">
                <Mail className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                <a href={`mailto:${s.email}`} className="break-all hover:text-primary">{s.email}</a>
              </li>
            )}
          </ul>
        </div>
      </div>

      <div className="gold-rule mx-auto max-w-content" aria-hidden="true" />
      <div className="mx-auto flex max-w-content flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6">
        <p>© {year} {s.site_name}. All rights reserved.</p>
        <Link
          to="/admin"
          className="glass inline-flex items-center gap-1.5 rounded-full px-4 py-2 font-medium text-primary transition-colors hover:bg-none hover:bg-primary hover:text-primary-foreground"
        >
          <Lock className="size-3.5" aria-hidden="true" /> Admin
        </Link>
      </div>
    </footer>
  )
}
