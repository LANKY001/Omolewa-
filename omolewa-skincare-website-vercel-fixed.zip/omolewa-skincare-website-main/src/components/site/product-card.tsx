import { Link } from '@tanstack/react-router'
import { ShoppingBag } from 'lucide-react'
import { toast } from 'sonner'
import { useCart } from '@/lib/cart'
import { formatNGN } from '@/lib/format'
import { SECTION_LABELS, type Product } from '@/lib/types'

export function ProductCard({ product }: { product: Product }) {
  const cart = useCart()

  return (
    <article className="floral-box floral-box-top glass lift group flex flex-col rounded-[1.75rem] p-3">
      <Link
        to="/product/$id"
        params={{ id: product.id }}
        className="relative block overflow-hidden rounded-[1.35rem] focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none"
      >
        <div className="aspect-[4/5] bg-muted">
          {product.image_url ? (
            <img
              src={product.image_url}
              alt={product.name}
              loading="lazy"
              className="size-full object-cover transition-transform duration-700 group-hover:scale-105 motion-reduce:transition-none"
            />
          ) : (
            <div className="flex size-full items-center justify-center font-display text-2xl text-muted-foreground">
              Omolewa
            </div>
          )}
        </div>
        <span className="glass absolute bottom-3 left-3 rounded-full px-3 py-1 text-[0.7rem] font-medium tracking-widest text-primary uppercase">
          {SECTION_LABELS[product.section]}
        </span>
        {!product.in_stock && (
          <span className="absolute right-3 bottom-3 rounded-full bg-foreground/80 px-3 py-1 text-xs text-background">
            {product.section === 'event' ? 'Fully booked' : 'Sold out'}
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-1 px-2 pt-4 pb-2">
        <p className="text-xs tracking-widest text-muted-foreground uppercase">
          {product.category}
        </p>
        <h3 className="text-2xl leading-tight font-semibold">
          <Link
            to="/product/$id"
            params={{ id: product.id }}
            className="transition-colors hover:text-primary"
          >
            {product.name}
          </Link>
        </h3>
        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <p className="text-lg font-medium text-primary">
            {formatNGN(product.price)}
            {product.price_unit && (
              <span className="ml-1 text-xs font-normal text-muted-foreground">
                {product.price_unit}
              </span>
            )}
          </p>
          <button
            type="button"
            disabled={!product.in_stock}
            onClick={() => {
              cart.add(product)
              toast.success(`${product.name} added to your bag`)
            }}
            aria-label={`Add ${product.name} to bag`}
            className="inline-flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md transition-all hover:scale-105 hover:shadow-lg focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-none disabled:opacity-40 motion-reduce:transition-none"
          >
            <ShoppingBag className="size-4" />
          </button>
        </div>
      </div>
    </article>
  )
}
