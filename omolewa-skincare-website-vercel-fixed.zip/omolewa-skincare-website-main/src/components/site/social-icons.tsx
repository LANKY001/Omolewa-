import { cn } from '@/lib/utils'
import { socialUrl, whatsappLink } from '@/lib/format'
import { useSettings } from '@/lib/settings-context'

type IconProps = { className?: string }

export function FacebookIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M24 12.07C24 5.45 18.63.07 12 .07S0 5.45 0 12.07c0 5.99 4.39 10.95 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3 1.79-4.67 4.53-4.67 1.31 0 2.69.24 2.69.24v2.95h-1.51c-1.49 0-1.96.93-1.96 1.87v2.25h3.33l-.53 3.47h-2.8v8.38C19.61 23.03 24 18.06 24 12.07z" />
    </svg>
  )
}

export function InstagramIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <rect x="2.5" y="2.5" width="19" height="19" rx="5.5" />
      <circle cx="12" cy="12" r="4.3" />
      <circle cx="17.6" cy="6.4" r="1.1" fill="currentColor" stroke="none" />
    </svg>
  )
}

export function TelegramIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" />
    </svg>
  )
}

export function TikTokIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M12.53.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
    </svg>
  )
}

export function WhatsAppIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M12 2.2a9.8 9.8 0 0 0-8.45 14.76L2.2 21.8l4.97-1.3A9.8 9.8 0 1 0 12 2.2z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinejoin="round"
      />
      <path
        fill="currentColor"
        d="M8.6 7.3c.2-.4.4-.4.7-.4h.6c.2 0 .4 0 .6.5l.8 1.9c.1.2.1.4 0 .6l-.4.6-.4.4c-.1.1-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.6-.1l.8-1c.2-.3.4-.2.6-.1l1.8.9c.3.1.4.2.5.3 0 .2 0 .9-.3 1.5-.3.7-1.6 1.3-2.2 1.3-.6.1-1.1.3-3.8-.8-3.2-1.3-5.2-4.6-5.4-4.8-.2-.2-1.3-1.7-1.3-3.3 0-1.5.8-2.3 1.1-2.6z"
      />
    </svg>
  )
}

/** Social buttons linked to the handles saved in the admin dashboard. */
export function SocialLinks({
  className,
  size = 'md',
}: {
  className?: string
  size?: 'sm' | 'md'
}) {
  const s = useSettings()
  const links = [
    { label: 'Facebook', href: socialUrl('facebook', s.facebook), Icon: FacebookIcon },
    { label: 'Instagram', href: socialUrl('instagram', s.instagram), Icon: InstagramIcon },
    { label: 'Telegram', href: socialUrl('telegram', s.telegram), Icon: TelegramIcon },
    { label: 'TikTok', href: socialUrl('tiktok', s.tiktok), Icon: TikTokIcon },
    {
      label: 'WhatsApp',
      href: s.whatsapp ? whatsappLink(s.whatsapp) : '',
      Icon: WhatsAppIcon,
    },
  ]
  const box = size === 'sm' ? 'size-8' : 'size-10'
  const icon = size === 'sm' ? 'size-3.5' : 'size-4.5'

  return (
    <ul className={cn('flex flex-wrap items-center gap-2', className)}>
      {links.map(({ label, href, Icon }) => (
        <li key={label}>
          {href ? (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${label} — opens in a new tab`}
              title={label}
              className={cn(
                box,
                'glass inline-flex items-center justify-center rounded-full text-primary transition-colors duration-200 hover:bg-none hover:bg-primary hover:text-primary-foreground motion-reduce:transition-none',
              )}
            >
              <Icon className={icon} />
            </a>
          ) : (
            <span
              title={`${label} coming soon`}
              aria-label={`${label} (not linked yet)`}
              className={cn(
                box,
                'glass inline-flex cursor-not-allowed items-center justify-center rounded-full text-primary/40',
              )}
            >
              <Icon className={icon} />
            </span>
          )}
        </li>
      ))}
    </ul>
  )
}
