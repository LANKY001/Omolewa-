import { Link } from '@tanstack/react-router'
import { useSettings } from '@/lib/settings-context'
import { cn } from '@/lib/utils'

/** Splits the site name into a script-like first word and a small subtitle. */
export function Brand({ className, light }: { className?: string; light?: boolean }) {
  const { site_name } = useSettings()
  const [first, ...rest] = site_name.trim().split(/\s+/)
  return (
    <Link
      to="/"
      className={cn('group flex flex-col leading-none', className)}
      aria-label={`${site_name} — home`}
    >
      <span
        className={cn(
          'font-display text-3xl font-semibold italic transition-colors',
          light ? 'text-cream' : 'text-primary group-hover:text-foreground',
        )}
      >
        {first}
      </span>
      {rest.length > 0 && (
        <span
          className={cn(
            'mt-1 text-[0.62rem] font-medium tracking-[0.32em] uppercase',
            light ? 'text-cream/80' : 'text-muted-foreground',
          )}
        >
          {rest.join(' ')}
        </span>
      )}
    </Link>
  )
}
