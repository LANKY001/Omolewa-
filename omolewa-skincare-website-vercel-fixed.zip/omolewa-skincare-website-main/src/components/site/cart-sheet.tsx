import { Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react'
import { Link } from '@tanstack/react-router'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart'
import { formatNGN, whatsappLink } from '@/lib/format'
import { useSettings } from '@/lib/settings-context'
import { WhatsAppIcon } from './social-icons'

export function CartSheet() {
  const cart = useCart()
  const settings = useSettings()

  const message = [
    `Hello ${settings.site_name}, I'd like to order:`,
    ...cart.items.map(
      (i) =>
        `• ${i.name} × ${i.qty} — ${formatNGN(i.price * i.qty)}${i.price_unit ? ` (${i.price_unit})` : ''}`,
    ),
    `Total: ${formatNGN(cart.total)}`,
  ].join('\n')

  return (
    <Sheet open={cart.open} onOpenChange={cart.setOpen}>
      <SheetContent side="right" className="flex w-[92vw] max-w-md flex-col bg-cream">
        <SheetHeader>
          <SheetTitle className="font-display text-3xl">Your bag</SheetTitle>
          <SheetDescription>
            {cart.count === 0
              ? 'Your bag is empty.'
              : `${cart.count} item${cart.count === 1 ? '' : 's'} · send your order on WhatsApp`}
          </SheetDescription>
        </SheetHeader>

        {cart.items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
            <ShoppingBag className="size-12 text-primary/40" aria-hidden="true" />
            <p className="text-muted-foreground">
              Discover glowing skincare and beautiful event rentals.
            </p>
            <Button asChild className="rounded-full" onClick={() => cart.setOpen(false)}>
              <Link to="/shop">Start shopping</Link>
            </Button>
          </div>
        ) : (
          <ul className="flex-1 space-y-3 overflow-y-auto px-4">
            {cart.items.map((item) => (
              <li key={item.id} className="glass flex gap-3 rounded-2xl p-2">
                {item.image_url && (
                  <img
                    src={item.image_url}
                    alt=""
                    className="size-20 shrink-0 rounded-xl object-cover"
                  />
                )}
                <div className="flex min-w-0 flex-1 flex-col">
                  <p className="truncate font-medium">{item.name}</p>
                  <p className="text-sm text-primary">
                    {formatNGN(item.price)}
                    {item.price_unit && (
                      <span className="ml-1 text-xs text-muted-foreground">
                        {item.price_unit}
                      </span>
                    )}
                  </p>
                  <div className="mt-auto flex items-center gap-2">
                    <button
                      type="button"
                      aria-label={`Decrease ${item.name}`}
                      onClick={() => cart.setQty(item.id, item.qty - 1)}
                      className="inline-flex size-7 items-center justify-center rounded-full border bg-white/60 hover:bg-white"
                    >
                      <Minus className="size-3" />
                    </button>
                    <span className="w-6 text-center text-sm tabular-nums">{item.qty}</span>
                    <button
                      type="button"
                      aria-label={`Increase ${item.name}`}
                      onClick={() => cart.setQty(item.id, item.qty + 1)}
                      className="inline-flex size-7 items-center justify-center rounded-full border bg-white/60 hover:bg-white"
                    >
                      <Plus className="size-3" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Remove ${item.name}`}
                      onClick={() => cart.remove(item.id)}
                      className="ml-auto inline-flex size-7 items-center justify-center rounded-full text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}

        {cart.items.length > 0 && (
          <SheetFooter className="border-t border-border/60">
            <div className="flex items-center justify-between text-lg">
              <span>Total</span>
              <span className="font-semibold text-primary">{formatNGN(cart.total)}</span>
            </div>
            <Button asChild size="lg" className="rounded-full">
              <a
                href={whatsappLink(settings.whatsapp, message)}
                target="_blank"
                rel="noopener noreferrer"
              >
                <WhatsAppIcon className="size-5" /> Order on WhatsApp
              </a>
            </Button>
            <Button variant="ghost" className="rounded-full" onClick={cart.clear}>
              Clear bag
            </Button>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  )
}
