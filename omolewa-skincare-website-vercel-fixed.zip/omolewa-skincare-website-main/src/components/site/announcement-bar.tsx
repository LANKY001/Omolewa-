import { Sparkles } from 'lucide-react'
import { useSettings } from '@/lib/settings-context'

export function AnnouncementBar() {
  const { announcement } = useSettings()
  if (!announcement.trim()) return null
  return (
    <div className="bg-primary text-primary-foreground">
      <p className="mx-auto flex max-w-content items-center justify-center gap-2 px-4 py-2 text-center text-xs tracking-wide sm:text-sm">
        <Sparkles className="size-3.5 shrink-0 text-gold" aria-hidden="true" />
        <span>{announcement}</span>
      </p>
    </div>
  )
}
