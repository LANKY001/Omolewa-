import { useEffect, useState } from 'react'
import { Link, useNavigate } from '@tanstack/react-router'
import { Menu, Search, ShoppingBag } from 'lucide-react'
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { useCart } from '@/lib/cart'
import { cn } from '@/lib/utils'
import { Brand } from './brand'
import { SocialLinks } from './social-icons'

function navLinks(className: string, activeClassName?: string) {
  const active = activeClassName ? { activeProps: { className: activeClassName } } : {}
  return [
    <Link key="home" to="/" className={className} activeOptions={{ exact: true }} {...active}>
      Home
    </Link>,
    <Link key="skincare" to="/shop" search={{ section: 'skincare' }} className={className} activeOptions={{ includeSearch: true }} {...active}>
      Skincare
    </Link>,
    <Link key="event" to="/shop" search={{ section: 'event' }} className={className} activeOptions={{ includeSearch: true }} {...active}>
      Event Hire
    </Link>,
    <Link key="about" to="/about" className={className} {...active}>
      About
    </Link>,
    <Link key="reviews" to="/reviews" className={className} {...active}>
      Reviews
    </Link>,
  ]
}

function SearchForm({ className, onDone }: { className?: string; onDone?: () => void }) {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  return (
    <form
      role="search"
      className={cn('relative', className)}
      onSubmit={(e) => {
        e.preventDefault()
        void navigate({ to: '/shop', search: { q: q.trim() || undefined } })
        onDone?.()
      }}
    >
      <label htmlFor={onDone ? 'mobile-search' : 'site-search'} className="sr-only">
        Search skincare and event items
      </label>
      <input
        id={onDone ? 'mobile-search' : 'site-search'}
        type="search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search serums, tents, chairs…"
        className="h-10 w-full rounded-full border border-white/80 bg-cream/70 pr-11 pl-4 text-sm shadow-inner outline-none placeholder:text-muted-foreground/80 focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/40"
      />
      <button
        type="submit"
        aria-label="Search"
        className="absolute top-1 right-1 inline-flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground transition-colors hover:bg-primary/85"
      >
        <Search className="size-4" />
      </button>
    </form>
  )
}

export function SiteHeader() {
  const cart = useCart()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const linkClass =
    'relative rounded-full px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-primary after:absolute after:inset-x-3 after:-bottom-0.5 after:h-px after:origin-left after:scale-x-0 after:bg-gold after:transition-transform hover:after:scale-x-100'

  return (
    <header
      className={cn(
        'swag-edge-bottom glass sticky top-0 z-40 border-x-0 border-t-0 transition-[background-color,box-shadow] duration-300 motion-reduce:transition-none',
        scrolled && 'glass-strong shadow-[0_14px_30px_-18px_oklch(0.4_0.12_15/0.5)]',
      )}
    >
      <div className="mx-auto flex h-18 max-w-content items-center gap-4 px-4 sm:px-6">
        <Brand className="shrink-0" />

        <nav aria-label="Main" className="ml-4 hidden lg:block">
          <ul className="flex items-center gap-1">
            {navLinks(linkClass, 'text-primary after:scale-x-100').map((link) => (
              <li key={link.key}>{link}</li>
            ))}
          </ul>
        </nav>

        <SearchForm className="ml-auto hidden w-64 md:block xl:w-80" />

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <button
            type="button"
            onClick={() => cart.setOpen(true)}
            aria-label={`Open bag, ${cart.count} item${cart.count === 1 ? '' : 's'}`}
            className="relative inline-flex size-11 items-center justify-center rounded-full text-foreground transition-colors hover:bg-white/60 hover:text-primary"
          >
            <ShoppingBag className="size-5" />
            <span
              className={cn(
                'absolute top-0.5 right-0.5 inline-flex min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[0.65rem] leading-5 font-semibold text-primary-foreground ring-2 ring-cream transition-transform motion-reduce:transition-none',
                cart.count === 0 && 'scale-0',
              )}
            >
              {cart.count > 99 ? '99+' : cart.count}
            </span>
          </button>

          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label="Open menu"
                className="inline-flex size-11 items-center justify-center rounded-full transition-colors hover:bg-white/60 hover:text-primary lg:hidden"
              >
                <Menu className="size-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[86vw] max-w-sm border-l-white/70 bg-cream">
              <SheetHeader>
                <SheetTitle className="sr-only">Menu</SheetTitle>
                <SheetDescription className="sr-only">
                  Browse the site and search items
                </SheetDescription>
                <Brand />
              </SheetHeader>
              <div className="flex flex-col gap-6 px-4">
                <SearchForm onDone={() => setMenuOpen(false)} />
                <nav aria-label="Mobile">
                  <ul className="flex flex-col">
                    {navLinks(
                      'block border-b border-border/60 py-3 font-display text-2xl transition-colors hover:text-primary',
                      'text-primary',
                    ).map((link) => (
                      <li key={link.key}>
                        <SheetClose asChild>{link}</SheetClose>
                      </li>
                    ))}
                  </ul>
                </nav>
                <SocialLinks size="sm" />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
