import { useState } from 'react'
import { useRouter } from '@tanstack/react-router'
import { Loader2, Save } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  FacebookIcon,
  InstagramIcon,
  TelegramIcon,
  TikTokIcon,
  WhatsAppIcon,
} from '@/components/site/social-icons'
import { adminSaveSettings } from '@/lib/admin-api'
import { useSettings } from '@/lib/settings-context'
import type { SiteSettings } from '@/lib/types'
import { Field, inputClass } from './field'

export function SettingsForm() {
  const router = useRouter()
  const current = useSettings()
  const [form, setForm] = useState<SiteSettings>(current)
  const [saving, setSaving] = useState(false)

  const bind = (key: keyof SiteSettings) => ({
    id: `s-${key}`,
    value: form[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value })),
    className: inputClass,
  })

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.site_name.trim()) return toast.error('The website name cannot be empty')
    setSaving(true)
    try {
      const trimmed = Object.fromEntries(
        Object.entries(form).map(([k, v]) => [k, v.trim()]),
      ) as unknown as SiteSettings
      await adminSaveSettings(trimmed)
      await router.invalidate()
      toast.success('Website details saved')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not save settings')
    } finally {
      setSaving(false)
    }
  }

  const card = 'glass flex flex-col gap-5 rounded-[1.75rem] p-6 sm:p-8'

  return (
    <form onSubmit={onSubmit} className="grid gap-8 lg:grid-cols-2">
      <section className={card}>
        <h2 className="text-3xl font-semibold">Website name &amp; header</h2>
        <Field id="s-site_name" label="Website name" hint="Shown in the header, footer and browser tab.">
          <Input {...bind('site_name')} required />
        </Field>
        <Field id="s-tagline" label="Tagline">
          <Input {...bind('tagline')} />
        </Field>
        <Field id="s-announcement" label="Announcement bar" hint="Leave empty to hide the bar above the header.">
          <Input {...bind('announcement')} />
        </Field>
        <Field id="s-about" label="About us text">
          <Textarea rows={6} {...bind('about')} />
        </Field>
      </section>

      <div className="flex flex-col gap-8">
        <section className={card}>
          <h2 className="text-3xl font-semibold">Contact &amp; address</h2>
          <Field id="s-address" label="Business address">
            <Textarea rows={3} {...bind('address')} placeholder="Shop 12, Admiralty Way, Lekki, Lagos" />
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="s-phone" label="Phone">
              <Input type="tel" {...bind('phone')} />
            </Field>
            <Field id="s-email" label="Email">
              <Input type="email" {...bind('email')} />
            </Field>
          </div>
          <Field id="s-whatsapp" label="WhatsApp order number" hint="All “Order now” buttons open a chat with this number, e.g. 08031234567 or 2348031234567.">
            <div className="relative">
              <WhatsAppIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-primary" />
              <Input type="tel" {...bind('whatsapp')} className={`${inputClass} pl-9`} />
            </div>
          </Field>
        </section>

        <section className={card}>
          <h2 className="text-3xl font-semibold">Social media</h2>
          <p className="-mt-2 text-sm text-muted-foreground">Paste a full profile link or just the @handle.</p>
          {([
            ['facebook', 'Facebook', FacebookIcon],
            ['instagram', 'Instagram', InstagramIcon],
            ['telegram', 'Telegram', TelegramIcon],
            ['tiktok', 'TikTok', TikTokIcon],
          ] as const).map(([key, label, Icon]) => (
            <Field key={key} id={`s-${key}`} label={label}>
              <div className="relative">
                <Icon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-primary" />
                <Input {...bind(key)} className={`${inputClass} pl-9`} placeholder={`@omolewa or https://…`} />
              </div>
            </Field>
          ))}
        </section>
      </div>

      <div className="lg:col-span-2">
        <Button type="submit" size="lg" className="w-full rounded-full sm:w-auto sm:px-10" disabled={saving}>
          {saving ? <Loader2 className="animate-spin" /> : <Save />} Save website details
        </Button>
      </div>
    </form>
  )
}
