import { useCallback, useEffect, useState } from 'react'
import { useRouter } from '@tanstack/react-router'
import { ImagePlus, Loader2, Pencil, Plus, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import {
  adminDeleteProduct,
  adminListProducts,
  adminSaveProduct,
  adminUploadImage,
  type ProductInput,
} from '@/lib/admin-api'
import { formatNGN } from '@/lib/format'
import { SECTION_LABELS, type Product, type Section } from '@/lib/types'
import { Field, inputClass } from './field'

const EMPTY: ProductInput = {
  name: '',
  section: 'skincare',
  category: '',
  price: 0,
  price_unit: null,
  description: '',
  details: '',
  image_url: '',
  featured: false,
  in_stock: true,
}

export function ProductsManager({ onSetupNeeded }: { onSetupNeeded: (v: boolean) => void }) {
  const router = useRouter()
  const [products, setProducts] = useState<Product[] | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [form, setForm] = useState<ProductInput>(EMPTY)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)

  const load = useCallback(async () => {
    try {
      const { products, setupNeeded } = await adminListProducts()
      setProducts(products)
      onSetupNeeded(setupNeeded)
      setLoadError(null)
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Could not load items')
    }
  }, [onSetupNeeded])

  useEffect(() => {
    void load()
  }, [load])

  const set = <K extends keyof ProductInput>(key: K, value: ProductInput[K]) =>
    setForm((f) => ({ ...f, [key]: value }))

  function reset() {
    setForm(EMPTY)
    setEditingId(null)
  }

  function edit(p: Product) {
    setEditingId(p.id)
    setForm({
      name: p.name,
      section: p.section,
      category: p.category,
      price: p.price,
      price_unit: p.price_unit,
      description: p.description ?? '',
      details: p.details ?? '',
      image_url: p.image_url ?? '',
      featured: p.featured,
      in_stock: p.in_stock,
    })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  async function onUpload(file: File | undefined) {
    if (!file) return
    setUploading(true)
    try {
      set('image_url', await adminUploadImage(file))
      toast.success('Photo uploaded')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name.trim()) return toast.error('Please enter the item name')
    if (!(form.price >= 0)) return toast.error('Please enter a valid price')
    setSaving(true)
    try {
      await adminSaveProduct(
        {
          ...form,
          name: form.name.trim(),
          category: form.category.trim() || 'General',
          price_unit: form.price_unit?.trim() || null,
          image_url: form.image_url?.trim() || null,
        },
        editingId ?? undefined,
      )
      toast.success(editingId ? 'Item updated' : 'Item posted to the website')
      reset()
      await load()
      await router.invalidate()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not save item')
    } finally {
      setSaving(false)
    }
  }

  async function onDelete(p: Product) {
    if (!window.confirm(`Delete “${p.name}”? This cannot be undone.`)) return
    try {
      await adminDeleteProduct(p.id)
      toast.success('Item deleted')
      if (editingId === p.id) reset()
      await load()
      await router.invalidate()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not delete item')
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
      <form onSubmit={onSubmit} className="glass flex flex-col gap-5 rounded-[1.75rem] p-6 sm:p-8">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-3xl font-semibold">{editingId ? 'Edit item' : 'Post a new item'}</h2>
          {editingId && (
            <Button type="button" variant="ghost" size="sm" onClick={reset}>
              <X /> Cancel edit
            </Button>
          )}
        </div>

        <Field id="p-name" label="Item name">
          <Input id="p-name" value={form.name} onChange={(e) => set('name', e.target.value)} required className={inputClass} placeholder="e.g. Rose Hydrating Toner" />
        </Field>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field id="p-section" label="Section">
            <select
              id="p-section"
              value={form.section}
              onChange={(e) => set('section', e.target.value as Section)}
              className="h-9 rounded-md border border-input bg-cream/80 px-3 text-sm outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
            >
              {(Object.keys(SECTION_LABELS) as Section[]).map((s) => (
                <option key={s} value={s}>{SECTION_LABELS[s]}</option>
              ))}
            </select>
          </Field>
          <Field id="p-category" label="Category" hint="e.g. Serums, Tents, Chairs & Tables">
            <Input id="p-category" value={form.category} onChange={(e) => set('category', e.target.value)} className={inputClass} list="category-suggestions" />
            <datalist id="category-suggestions">
              {[...new Set((products ?? []).map((p) => p.category))].map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </Field>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field id="p-price" label="Price (₦ NGN)">
            <Input id="p-price" type="number" min={0} step="1" inputMode="numeric" value={Number.isFinite(form.price) ? form.price : ''} onChange={(e) => set('price', e.target.valueAsNumber)} className={inputClass} required />
          </Field>
          <Field id="p-unit" label="Price unit (optional)" hint="e.g. per day, per chair">
            <Input id="p-unit" value={form.price_unit ?? ''} onChange={(e) => set('price_unit', e.target.value)} className={inputClass} />
          </Field>
        </div>

        <Field id="p-desc" label="Short description">
          <Textarea id="p-desc" rows={3} value={form.description ?? ''} onChange={(e) => set('description', e.target.value)} className={inputClass} />
        </Field>

        <Field id="p-details" label="Details" hint="One detail per line — shown as a checklist on the item page.">
          <Textarea id="p-details" rows={4} value={form.details ?? ''} onChange={(e) => set('details', e.target.value)} className={inputClass} />
        </Field>

        <Field id="p-image-url" label="Photo" hint="Upload a photo or paste an image link.">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="size-24 shrink-0 overflow-hidden rounded-xl border bg-muted">
              {form.image_url ? (
                <img src={form.image_url} alt="Preview" className="size-full object-cover" />
              ) : (
                <div className="flex size-full items-center justify-center text-muted-foreground">
                  <ImagePlus className="size-6" aria-hidden="true" />
                </div>
              )}
            </div>
            <div className="flex flex-1 flex-col gap-2">
              <label className="inline-flex w-fit cursor-pointer items-center gap-2 rounded-full border border-primary/30 bg-cream/80 px-4 py-2 text-sm text-primary transition-colors hover:bg-cream focus-within:ring-[3px] focus-within:ring-ring/50">
                {uploading ? <Loader2 className="size-4 animate-spin" /> : <ImagePlus className="size-4" />}
                {uploading ? 'Uploading…' : 'Upload photo'}
                <input type="file" accept="image/*" className="sr-only" disabled={uploading} onChange={(e) => void onUpload(e.target.files?.[0])} />
              </label>
              <Input id="p-image-url" value={form.image_url ?? ''} onChange={(e) => set('image_url', e.target.value)} placeholder="https://…" className={inputClass} />
            </div>
          </div>
        </Field>

        <div className="flex flex-wrap gap-6">
          <label className="flex items-center gap-3 text-sm">
            <Switch checked={form.featured} onCheckedChange={(v) => set('featured', v)} aria-label="Feature on home page" />
            Feature on home page
          </label>
          <label className="flex items-center gap-3 text-sm">
            <Switch checked={form.in_stock} onCheckedChange={(v) => set('in_stock', v)} aria-label="Available" />
            Available / in stock
          </label>
        </div>

        <Button type="submit" size="lg" className="rounded-full" disabled={saving || uploading}>
          {saving ? <Loader2 className="animate-spin" /> : editingId ? <Pencil /> : <Plus />}
          {editingId ? 'Save changes' : 'Post item'}
        </Button>
      </form>

      <section className="glass flex flex-col gap-4 rounded-[1.75rem] p-6 sm:p-8" aria-label="Posted items">
        <h2 className="text-3xl font-semibold">
          Posted items {products && <span className="text-lg text-muted-foreground">({products.length})</span>}
        </h2>
        {loadError && <p role="alert" className="text-sm text-destructive">{loadError}</p>}
        {!products && !loadError && (
          <ul className="space-y-3">
            {[0, 1, 2].map((i) => <li key={i} className="h-20 animate-pulse rounded-2xl bg-white/50" />)}
          </ul>
        )}
        {products?.length === 0 && (
          <p className="text-muted-foreground">No items yet — post your first one with the form.</p>
        )}
        <ul className="flex max-h-[70vh] flex-col gap-3 overflow-y-auto pr-1">
          {products?.map((p) => (
            <li key={p.id} className="flex items-center gap-3 rounded-2xl bg-white/50 p-2">
              <div className="size-16 shrink-0 overflow-hidden rounded-xl bg-muted">
                {p.image_url && <img src={p.image_url} alt="" className="size-full object-cover" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{p.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {SECTION_LABELS[p.section]} · {p.category} · {formatNGN(p.price)}
                  {p.featured && ' · ★ Featured'}
                  {!p.in_stock && ' · Unavailable'}
                </p>
              </div>
              <Button variant="ghost" size="icon-sm" onClick={() => edit(p)} aria-label={`Edit ${p.name}`}>
                <Pencil />
              </Button>
              <Button variant="ghost" size="icon-sm" onClick={() => void onDelete(p)} aria-label={`Delete ${p.name}`} className="text-destructive hover:text-destructive">
                <Trash2 />
              </Button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
