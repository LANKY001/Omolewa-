import { useState } from 'react'
import { Loader2, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getSupabase } from '@/lib/supabase'
import { SETUP_MESSAGE } from '@/lib/admin-api'

export function LoginForm({ notice }: { notice?: string | null }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setError(null)
    const { error } = await getSupabase().auth.signInWithPassword({
      email: email.trim(),
      password,
    })
    setPending(false)
    if (error) {
      setError(
        /not confirmed/i.test(error.message)
          ? `This admin account still needs to be activated. ${SETUP_MESSAGE}`
          : /invalid/i.test(error.message)
            ? 'Incorrect email or password.'
            : error.message,
      )
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <form onSubmit={onSubmit} className="floral-box floral-box-lg swag-edge glass flex flex-col gap-5 rounded-[2rem] p-8 pt-14">
        <div className="text-center">
          <span className="mx-auto inline-flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Lock className="size-5" aria-hidden="true" />
          </span>
          <h1 className="mt-3 text-4xl font-semibold">Admin sign in</h1>
          <p className="mt-1 text-sm text-muted-foreground">Manage items, site details and reviews.</p>
        </div>
        {notice && <p role="alert" className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{notice}</p>}
        <div className="flex flex-col gap-2">
          <Label htmlFor="admin-email">Email</Label>
          <Input id="admin-email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} className="bg-cream/80" />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="admin-password">Password</Label>
          <Input id="admin-password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} className="bg-cream/80" />
        </div>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <Button type="submit" size="lg" className="rounded-full" disabled={pending}>
          {pending && <Loader2 className="animate-spin" />} Sign in
        </Button>
      </form>
    </div>
  )
}
