import { useEffect, useState } from 'react'
import { useRouter } from '@tanstack/react-router'
import { Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Stars } from '@/components/site/stars'
import { adminDeleteReview, adminListReviews } from '@/lib/admin-api'
import { formatDate } from '@/lib/format'
import type { Review } from '@/lib/types'

export function ReviewsManager() {
  const router = useRouter()
  const [reviews, setReviews] = useState<Review[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    try {
      setReviews(await adminListReviews())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load reviews')
    }
  }

  useEffect(() => {
    void load()
  }, [])

  async function onDelete(r: Review) {
    if (!window.confirm(`Delete the review from ${r.name}?`)) return
    try {
      await adminDeleteReview(r.id)
      setReviews((list) => list?.filter((x) => x.id !== r.id) ?? null)
      await router.invalidate()
      toast.success('Review deleted')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not delete review')
    }
  }

  return (
    <section className="glass flex flex-col gap-4 rounded-[1.75rem] p-6 sm:p-8" aria-label="Customer reviews">
      <h2 className="text-3xl font-semibold">Customer reviews</h2>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      {!reviews && !error && <div className="h-24 animate-pulse rounded-2xl bg-white/50" />}
      {reviews?.length === 0 && <p className="text-muted-foreground">No reviews yet.</p>}
      <ul className="flex flex-col gap-3">
        {reviews?.map((r) => (
          <li key={r.id} className="flex gap-4 rounded-2xl bg-white/50 p-4">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <p className="font-medium">{r.name}</p>
                <Stars rating={r.rating} />
                <span className="text-xs text-muted-foreground">{formatDate(r.created_at)}</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{r.comment}</p>
            </div>
            <Button variant="ghost" size="icon-sm" onClick={() => void onDelete(r)} aria-label={`Delete review from ${r.name}`} className="text-destructive hover:text-destructive">
              <Trash2 />
            </Button>
          </li>
        ))}
      </ul>
    </section>
  )
}
