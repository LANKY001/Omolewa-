# Deploying this project to Vercel

This project uses TanStack Start with Nitro for Vercel deployment.

## Vercel project settings

- Framework Preset: TanStack Start (or leave it as Other if the preset is unavailable; `vercel.json` declares TanStack Start)
- Root Directory: `omolewa-skincare-website-main` if the repository contains this folder inside another repository; otherwise `.`
- Build Command: `npm run build` (or leave the detected default)
- Output Directory: leave blank / use the detected default. Do not set it to `public` or `dist/client` for this full-stack app.
- Install Command: `npm install`

## Environment variables

The site has fallback Supabase URL and publishable key values in `src/lib/config.ts`. If using a different Supabase project, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` in Vercel Project Settings → Environment Variables, then redeploy. Do not put service-role keys or other secrets in `VITE_` variables.

## Deploy

Import the project/repository in Vercel and deploy again after uploading these updated files. If the project already exists, open Settings → Build and Deployment and ensure the Root Directory and install/build settings above are correct, then trigger a new deployment.
