-- Omolewa Event & Skincare — Supabase setup
-- Run this once in Supabase Dashboard → SQL Editor → New query → Run.
-- It is safe to run again: every statement is idempotent.

-- ---------------------------------------------------------------------------
-- Admin helper: only this signed-in email can change site content.
-- ---------------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select coalesce(auth.jwt() ->> 'email', '') = 'omolewaevnt2@gmail.com'
$$;

-- Confirm the admin account so it can sign in straight away.
update auth.users
set email_confirmed_at = coalesce(email_confirmed_at, now())
where email = 'omolewaevnt2@gmail.com';

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  section text not null check (section in ('skincare', 'event')),
  category text not null default 'General',
  price numeric(12, 2) not null default 0,
  price_unit text,
  description text,
  details text,
  image_url text,
  featured boolean not null default false,
  in_stock boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id int primary key default 1 check (id = 1),
  site_name text,
  tagline text,
  announcement text,
  about text,
  address text,
  phone text,
  email text,
  whatsapp text,
  facebook text,
  instagram text,
  telegram text,
  tiktok text,
  updated_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  rating int not null check (rating between 1 and 5),
  comment text not null check (char_length(comment) between 1 and 1500),
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.site_settings enable row level security;
alter table public.reviews enable row level security;

-- ---------------------------------------------------------------------------
-- Policies
-- ---------------------------------------------------------------------------
drop policy if exists "products are public" on public.products;
create policy "products are public" on public.products for select using (true);
drop policy if exists "admin manages products" on public.products;
create policy "admin manages products" on public.products for all
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "settings are public" on public.site_settings;
create policy "settings are public" on public.site_settings for select using (true);
drop policy if exists "admin manages settings" on public.site_settings;
create policy "admin manages settings" on public.site_settings for all
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "reviews are public" on public.reviews;
create policy "reviews are public" on public.reviews for select using (true);
drop policy if exists "anyone can leave a review" on public.reviews;
create policy "anyone can leave a review" on public.reviews for insert with check (true);
drop policy if exists "admin deletes reviews" on public.reviews;
create policy "admin deletes reviews" on public.reviews for delete using (public.is_admin());

-- ---------------------------------------------------------------------------
-- Storage bucket for item photos uploaded from the admin dashboard
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

drop policy if exists "product images are public" on storage.objects;
create policy "product images are public" on storage.objects for select
  using (bucket_id = 'product-images');
drop policy if exists "admin uploads product images" on storage.objects;
create policy "admin uploads product images" on storage.objects for insert
  with check (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "admin updates product images" on storage.objects;
create policy "admin updates product images" on storage.objects for update
  using (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "admin deletes product images" on storage.objects;
create policy "admin deletes product images" on storage.objects for delete
  using (bucket_id = 'product-images' and public.is_admin());

-- ---------------------------------------------------------------------------
-- Starter content (only inserted when the tables are empty)
-- ---------------------------------------------------------------------------
insert into public.site_settings (id, site_name, tagline, announcement, about, address, phone, email, whatsapp)
values (
  1,
  'Omolewa Event and Skincare',
  'Radiant skin. Unforgettable celebrations.',
  'Free Lagos delivery on skincare orders above ₦50,000 · Book event rentals early for December!',
  'Omolewa brings together two passions: skin that glows and celebrations that dazzle. We hand-pick gentle, effective skincare made with African botanicals, and we rent out beautifully kept tents, chairs, tables and décor for weddings, birthdays, owambes and corporate events across Nigeria.',
  'Lagos, Nigeria',
  '+234 800 000 0000',
  'omolewaevnt2@gmail.com',
  '2348000000000'
)
on conflict (id) do nothing;

insert into public.products (name, section, category, price, price_unit, description, details, image_url, featured)
select * from (values
  ('Vitamin C Glow Serum', 'skincare', 'Serums', 18500::numeric, null::text,
   'A lightweight brightening serum that fades dark spots and leaves skin luminous.',
   E'30ml amber dropper bottle\n15% stabilised vitamin C\nSuitable for all skin types\nUse morning and night',
   '/img/p-glow-serum.webp', true),
  ('Whipped Shea Body Butter', 'skincare', 'Body Care', 12000, null,
   'Rich, melt-in raw African shea whipped with coconut oil for deep, lasting moisture.',
   E'250g jar\n100% raw Ghanaian shea\nFragrance: soft vanilla\nGreat for dry skin and stretch marks',
   '/img/p-shea-butter.webp', true),
  ('African Black Soap Set', 'skincare', 'Cleansers', 9500, null,
   'Traditional black soap bars with a gentle foaming wash for clear, balanced skin.',
   E'2 soap bars + 200ml liquid wash\nPlantain skin ash & palm kernel oil\nHelps with acne and oily skin',
   '/img/p-black-soap.webp', true),
  ('Pagoda Party Tent', 'event', 'Tents', 150000, 'per day',
   'Elegant white pagoda tent with draped cream fabric — perfect for weddings and owambes.',
   E'Seats up to 150 guests\nIncludes drapes and fairy lights\nSetup and pickup included in Lagos',
   '/img/p-tent.webp', true),
  ('Gold Chiavari Chairs', 'event', 'Chairs & Tables', 2500, 'per chair',
   'Classic gold chiavari chairs with cream cushions to elevate any reception.',
   E'Minimum order: 50 chairs\nCushions included\nRound banquet tables available',
   '/img/p-chairs.webp', true),
  ('Luxury Table Décor Package', 'event', 'Décor', 45000, 'per table',
   'Gold candelabra centrepieces with fresh blush roses, runners and charger plates.',
   E'Fresh or silk flowers\nGold charger plates & napkins\nCustom colour themes available',
   '/img/p-decor.webp', true)
) as seed(name, section, category, price, price_unit, description, details, image_url, featured)
where not exists (select 1 from public.products);

-- Refresh the API schema cache so the new tables are available immediately.
notify pgrst, 'reload schema';
