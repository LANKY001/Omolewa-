# AGENTS.md

Guidance for AI agents and developers working on the Omolewa Event and Skincare website.

## Overview

This is the marketing and catalogue site for a Lagos business that sells skincare and rents out event items. Visitors browse items, see prices in NGN, and order through WhatsApp links (`wa.me`). The site has no payment processing. An admin manages content at `/admin`.

**Persistence is Supabase only.** The user explicitly asked for no Netlify Blobs, Netlify DB, Netlify Functions or other host-specific APIs, so the site stays portable to Vercel, Cloudflare and other hosts. Don't add server functions or platform storage. Use `@supabase/supabase-js` from route loaders and components.

## Stack

TanStack Start (React 19, Vite 8, file-based routing), Tailwind CSS 4 with theme variables in `src/styles.css`, shadcn/ui components in `src/components/ui`, sonner for toasts, lucide-react for icons, and Supabase for Postgres, Auth and Storage.

## Key directories

```
supabase/setup.sql          Idempotent schema, RLS policies, storage bucket, admin confirm, seed data. The user runs it in the Supabase SQL editor.
src/lib/config.ts           Supabase URL and publishable key (env overrides), ADMIN_EMAIL, bucket name
src/lib/supabase.ts         Lazy client singleton; isMissingTable() detects that setup.sql hasn't been run
src/lib/data.ts             Public reads (settings, products, reviews) and review insert, with fixture fallback
src/lib/admin-api.ts        Admin writes (products CRUD, image upload, settings upsert, review delete)
src/lib/fixtures.ts         DEFAULT_SETTINGS, DEMO_PRODUCTS (ids start with "demo-"), DEMO_REVIEWS
src/lib/settings-context.tsx Site settings from the root loader, read with useSettings()
src/lib/cart.tsx            Bag state (localStorage, hydrated in useEffect)
src/lib/format.ts           formatNGN, whatsappLink/normalizeWhatsapp (0803… → 234803…), socialUrl
src/components/site/        Header, announcement bar, footer (with Admin button), bag sheet, product card, social icons, stars
src/components/admin/       Login form, products manager, settings form, reviews manager
src/routes/                 index, shop (search params q/section/category/sort), product.$id, about, reviews, admin
public/img/                 AI-generated webp photos, floral-corner.svg and swag.svg ornaments
```

## Conventions and decisions

- **Settings flow**: the `__root` loader calls `fetchSettings()` (merged over DEFAULT_SETTINGS) and the result is provided through context. After an admin saves anything, call `router.invalidate()` so loaders refetch.
- **Fallbacks**: if a table is missing (PGRST205/42P01) or the network fails, the public pages show fixtures instead of erroring. Product ids starting with `demo-` always resolve from the fixtures.
- **Security**: the publishable key is public. Every write is protected by RLS using `public.is_admin()`, which compares `auth.jwt()->>'email'` to the admin email. If you change the admin email, update both `supabase/setup.sql` and `src/lib/config.ts`. Never put passwords or secret keys in code.
- **Design system**: use these classes from `src/styles.css`, in `@layer components`:
  - `.glass` / `.glass-strong` for the liquid-glass panels
  - `.floral-box` (plus `-lg` and `-top`) for corner flowers on item boxes
  - `.swag-edge` for the top drape on section bars, and `.swag-edge-bottom` for the drape under the header
  - `.lift` for the hover lift
  - `.gold-rule` for the gold divider

  `.glass` sets `background` with a gradient, so a hover solid colour needs `hover:bg-none hover:bg-primary`. Headings use Cormorant Garamond and body text uses Jost, both loaded from Google Fonts in `__root.tsx`.
- **Currency**: always format prices with `formatNGN`.
- **Images**: they're served straight from `/img/*.webp` (already resized). The site doesn't use a host image CDN, to stay portable. Admin uploads go to the Supabase Storage bucket `product-images`.
- Read `localStorage` and `window` only inside effects, because pages are server-rendered.

## Commands

`pnpm dev`, `pnpm build`, `pnpm typecheck`, `pnpm lint`, `pnpm test`.
