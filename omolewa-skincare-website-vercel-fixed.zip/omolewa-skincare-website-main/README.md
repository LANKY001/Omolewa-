# Omolewa Event and Skincare

The website for **Omolewa Event and Skincare**, a Lagos business that sells botanical skincare and rents out event items like party tents, chiavari chairs, banquet tables, and luxury table décor.

It has a liquid-glass design: cream frosted panels on a light-red background, flowers on the corners of every item box, draped fabric "swag" edges on the section bars, and a Nigerian party tent photo behind the hero. Prices are shown in **₦ NGN**, and every order goes through **WhatsApp**.

## Features

- **Announcement bar** above a **sticky header**. The header has a working search bar, a bag button with an item-count badge, and a mobile menu.
- **Home page**: the party-tent hero, the skincare and event-hire showcases, an about teaser, recent reviews, and a WhatsApp call to action.
- **Shop** (`/shop`): live search, section and category filters, and price sorting. Filters live in the URL, so a filtered view can be shared.
- **Item pages** (`/product/:id`): photo, price, details, a quantity picker, an **Order/Book now on WhatsApp** button (pre-filled message to the admin's number), and an Add to bag button.
- **Bag**: a drawer where several items can be sent as a single WhatsApp order.
- **About** (`/about`): the business story, services, address and contact details, and social links.
- **Reviews** (`/reviews`): visitors leave a star rating and a comment. The page shows the average rating.
- **Social icons** for Facebook, Instagram, Telegram, TikTok and WhatsApp. Each links to the handle saved in the admin dashboard.
- **Admin dashboard** (`/admin`, the button at the bottom of every page):
  - Post, edit and delete items, with name, section, category, price, unit, description, details, a photo upload, a featured flag and availability.
  - Change the website name, tagline, announcement, about text, **address**, phone, email, **WhatsApp order number** and social media handles.
  - Delete reviews.

## Tech

- TanStack Start (React 19, Vite 8) and Tailwind CSS 4
- **Supabase** for the database (Postgres), admin sign-in (Supabase Auth) and photo storage (Supabase Storage)
- All data access runs in the browser and in route loaders through `@supabase/supabase-js`. The app doesn't use any host-specific storage or functions.

## One-time Supabase setup

1. Open your Supabase project → **SQL Editor** → **New query**.
2. Paste the contents of [`supabase/setup.sql`](supabase/setup.sql) and click **Run**.

The script:

- creates the `products`, `site_settings` and `reviews` tables
- creates the public `product-images` storage bucket
- adds the Row Level Security rules: everyone can read and post reviews, and only the admin can change content
- activates the admin account
- adds the starter items

Until the script runs, the site shows the built-in starter items so it never looks empty.

Admin sign-in uses the Supabase Auth account **omolewaevnt2@gmail.com**. That account is already registered. The setup script confirms it, so no email link is needed. To change the password, use Supabase → Authentication → Users.

## Run locally

```bash
pnpm install
pnpm dev        # http://localhost:3000
```

The app points at the Omolewa Supabase project by default. To use a different project, copy `.env.example` to `.env` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.

## Deploying to other hosts

- **Netlify** works as-is (`netlify.toml`).
- **Vercel, Cloudflare Pages and other hosts**: the app code is host-agnostic. Swap `@netlify/vite-plugin-tanstack-start` in `vite.config.ts` for the matching TanStack Start / Nitro preset for that host, and set the two `VITE_SUPABASE_*` variables if you're using a different Supabase project.
